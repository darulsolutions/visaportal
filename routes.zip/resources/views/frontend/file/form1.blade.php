    @extends('frontend.layout.app')
    @section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Form 1</h1>
                    </div>
                    <div class="col-sm-6">

                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <style>
                 
        </style>

        <section style="background-image:url('frontend/dist/img/form1.jpg'); height: 783px; background-repeat: no-repeat; background-position: center;">
        <p style="position: absolute; top: 36.5%; left: 47%;">Name ahmer</p>
        <p style="position: absolute; top: 39%; left: 50%;">Name ahmer</p>
        </section>

    </div>
    <!-- /.content-wrapper -->
    @stop