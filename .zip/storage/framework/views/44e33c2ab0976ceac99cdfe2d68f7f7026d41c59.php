<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">File Details</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4">

                                <div class="row">
                                    <div class="col-sm-12">
                                        <table id="example1"
                                            class="table table-bordered table-striped dataTable dtr-inline" role="grid"
                                            aria-describedby="example1_info">
                                            <thead>
                                                <tr role="row">
                                                    <th class="sorting_asc" tabindex="0" aria-controls="example1"
                                                        rowspan="1" colspan="1" aria-sort="ascending"
                                                        aria-label="Rendering engine: activate to sort column descending">
                                                        File #</th>
                                                    <th class="sorting" tabindex="0" aria-controls="example1"
                                                        rowspan="1" colspan="1"
                                                        aria-label="Browser: activate to sort column ascending">Country
                                                    </th>
                                                    <th class="sorting" tabindex="0" aria-controls="example1"
                                                        rowspan="1" colspan="1"
                                                        aria-label="Platform(s): activate to sort column ascending">
                                                        Visa City</th>
                                                    <th class="sorting" tabindex="0" aria-controls="example1"
                                                        rowspan="1" colspan="1"
                                                        aria-label="Engine version: activate to sort column ascending">
                                                        Visa Number / ID Number</th>

                                                    <th>Visa Sender Name</th>
                                                    <th>Total Number of Visa</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(isset($filesList) && !empty($filesList)): ?>
                                                    <?php $__empty_1 = true; $__currentLoopData = $filesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr role="row" class="odd">
                                                            <td tabindex="0" class="sorting_1"> <b style="font-size: 25px"><a href="<?php echo e(isset($file->id) && !empty($file->id) ? url('/file-details').'/'.$file->id : ' '); ?>"><?php echo e(isset($file->id) && !empty($file->id) ? $file->id : 'N/A'); ?></b></a> <br><span style="font-size: 15px"><?php echo e(isset($file->created_at) && !empty($file->created_at) ? $file->created_at : 'N/A'); ?></span></td>
                                                            <td><?php echo e(isset($file->country) && !empty($file->country) ? $file->country : 'N/A'); ?></td>
                                                            <td><?php echo e(isset($file->city) && !empty($file->city) ? $file->city : 'N/A'); ?></td>
                                                            <?php
                                                                $total_visa_count = 0;
                                                                $employer = DB::table('employer_details')->where('file_id',$file->id)->get();
                                                                $categories = DB::table('categories')->get();
                                                                $employment_details = DB::table('employment_details')->select('*')->where('file_id',$file->id)->get();
                                                                $sender = DB::table('sender_details')->where('file_id',$file->id)->get();
                                                                $employee_details = DB::table('employee_details')->where('file_id',$file->id)->get();
                                                                foreach ($employment_details as $visa) {
                                                                    $total_visa_count = $total_visa_count + $visa->total_visa;

                                                                }

                                                            ?>
                                                            <?php $__empty_2 = true; $__currentLoopData = $employer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                            <td style="font-size: 25px">Visa &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($item->visa_number); ?><br>ID &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($item->id_number); ?></td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                            <td >Not found</td>
                                                            <?php endif; ?>
                                                            
                                                            <?php $__empty_2 = true; $__currentLoopData = $sender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                            <td ><?php echo e($item->name); ?></td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>

                                                            <td >Not found</td>
                                                            <?php endif; ?>
                                                            <td>Total Visa &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                <?php echo e($total_visa_count); ?>

                                                                <?php $__currentLoopData = $employment_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($visa->category_id == $item2->id): ?>
                                                                            (<?php echo e($visa->total_visa); ?> <?php echo e($item2->ar_name); ?>)
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <br>Total Stamped Visa &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1
                                                                <br>Total Remaining Visa &nbsp;&nbsp;&nbsp;
                                                                    
                                                                </td>
                                                            <td>
                                                                <form method="get" action="<?php echo e(url('add-employee')); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="id" value="<?php echo e(isset($file->id) && !empty($file->id) ? $file->id : ''); ?>">
                                                                    <button type="submit" class="btn btn-block btn-outline-info btn-sm">Add Employee</button>
                                                                </form>
                                                                <a href="<?php echo e(url('file_permission_print')); ?>" type="button" class="btn btn-block btn-outline-info btn-sm">Permission Forms</a>
                                                            </td>
                                                            
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <tr role="row" class="odd text-center">
                                                            <td colspan="7">Empty...</th>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
    </section>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visa_portal_BI\resources\views/frontend/file/file_listing.blade.php ENDPATH**/ ?>