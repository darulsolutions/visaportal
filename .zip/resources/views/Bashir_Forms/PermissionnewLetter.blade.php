

    <title>Permission new Letter</title>
    <style>
          @media(max-width: 450px){
            form,table{
                width: 100% !important;
                font-size: 13px;
            }
            .mainSection{
                padding:10px !important;
            }

        }
    </style>

  <div id="printableArea">
    <div class="mainSection"style="padding: 30px;font-size:20px">
        <form action="" style="width:70%;margin: 0 auto;">
            <p style="text-align: end;">Annex-A</p>
            <p style="text-align: center;font-weight: 600;text-decoration: underline;">APPLICATION UNDER RULE (19) OF EMIGRATION RULES 1979</p>
    <p>
        To,<br>
        The Protector of Emigrants, <br>
        Karachi.

    </p>
    <p>Subject: <span class="permission" style="text-decoration: underline;font-weight: 600;
      padding-left: 10%;">PERMISSION TO PROCESS EMPLOYMENT FOR ABROAD</span></p>
      <p>
        Dear Sir,
      </p>
      <p style="padding-left: 5%;">
        We have been advised by M/mosssa Abdullah usman al abiyanthrough M/s Bashir Ibrahim Enterprises to process placement of workers, detailed below, for employment with them (Copies of demand letter attached).
      </p>
      <table style="width: 100%; border-collapse: collapse;text-align: center;">
        <tr style="border:1px solid;">
            <td style="border:1px solid;font-weight: 600;">S.No.</td>
            <td style="border:1px solid;font-weight: 600;">Category of Worker(s)</td>
            <td style="border:1px solid;font-weight: 600;">Number required</td>
            <td style="border:1px solid black;font-weight: 600"> Monthly Salary </td>
            <td style="border:1px solid black;font-weight: 600">Contract Period</td>
            <td style="border:1px solid black;font-weight: 600">Remarks</td>
        </tr>
        <tr style="border:1px solid;">
            <td style="border:1px solid">1</td>
            <td style="border:1px solid">driver</td>
            <td style="border:1px solid;font-weight: 600;">01 </td>
            <td style="border:1px solid black;"> 1000SAR </td>
            <td style="border:1px solid black;">2 YEARS</td>
            <td style="border:1px solid black;color:white">Name</td>
        </tr>
        <tr style="border:1px solid;">
            <td style="border:1px solid">2</td>
            <td style="border:1px solid black;color: white;">Medical</td>
            <td style="border:1px solid black;color: white;;font-weight: 600;text-decoration: underline;">From Candidate </td>
            <td style="border:1px solid black;color:white"> Name </td>
            <td style="border:1px solid black;color:white">Name</td>
            <td style="border:1px solid black;color:white">Name</td>
        </tr>
        <tr style="border:1px solid;">
            <td style="border:1px solid">3</td>
            <td style="border:1px solid black;color: white;">Work Permit</td>
            <td style="border:1px solid black;color: white;;font-weight: 600;">Visa Arranged by Candidate </td>
            <td style="border:1px solid black;color:white"> Name </td>
            <td style="border:1px solid black;color:white">Name</td>
            <td style="border:1px solid black;color:white">Name</td>
        </tr>
        <tr style="border:1px solid;">
            <td style="border:1px solid">4</td>
            <td style="border:1px solid black;color: white;">Levy (If Applicable)</td>
            <td style="border:1px solid black;color: white;;font-weight: 600;">NILL </td>
            <td style="border:1px solid black;color:white"> Name </td>
            <td style="border:1px solid black;color:white">Name</td>
            <td style="border:1px solid black;color:white">Name</td>
        </tr>

    </table>
    <p style="margin-left: 2%;"> <span style="font-weight: 600;"> Other Fringe Benefits: </span>Accommodation Free: Food Free or 25% of the pay:
        Medical Free: Transport Free: Economy Class Round Air Trip Free or Free Passage
        Not provided: Return Air Passage Free: Overtime and other fringe benefits according to Local Labour Laws.
        </p>
        <p style="margin-left: 2%;">The process will be carried out through:</p>
        <p style="margin-left: 7%;">(a) Advertisement, Collection of CVs. Interview/Test and Recruitment <br>
            (b) Advertisement, Interview/Test and Recruitment <br>
            (c) Recruitment from left over CVs against a previous demand <br>
            (d) Nominees of the employer <br>
</p>
<p style="margin-left: 2%;">The process will be completed in the following premises:</p>
<p style="margin-left: 7%;">
    (i) Approved Head Office at ____________________ <br>
    (ii) Approved Branch Office at __________________ <br>
    (iii) Other place(s)  ___________________________ <br>

</p>
<p style="margin-left: 2%;margin-bottom: 70px;"> <span style="font-weight: 600;">NOTE: </span> Strike out which is nor relevant and authenticate it with stamp and signature.</p>

    <p style="text-align: end;"> Stamp & Signature of OEP</p>
    <p style="margin-left: 2%;"> The permission has been granted on the following conditions. The Permission is valid for 120 days. Please get it revalidated, of required, immediately on its expiry.</p>
    <p style="text-align: center;font-weight: 600;">OR</p>
    <p> <span style="font-weight: 600;margin-left: 2%;margin-bottom: 70px;">The</span>  permission has not been granted due to the following reasons:</p>
    <p style="text-align: end;">Protector of Emigrants</p>


    </form>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->

</div>
