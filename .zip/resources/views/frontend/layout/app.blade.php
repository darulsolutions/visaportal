@include('frontend.layout.header')
@include('frontend.layout.sidebar')
@yield('content')
@include('frontend.layout.footer')
