    
    <?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Add Employee</h1>
                    </div>
                    <div class="col-sm-6">

                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!--New File Entry Form Start-->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <!-- form start -->
                            <form role="form" method="post" action="<?php echo e(url('add-employee')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">

                                    <h4 class="add_file_section"> Employee Details: File# <?php echo e(isset($id) && !empty($id) ? $id : ''); ?></h4>
                                    <hr>
                                    <input class="form-control" type="hidden" name="id" value="<?php echo e(isset($id) && !empty($id) ? $id : ''); ?>">
                                    <div class="row">
                                        <div class="form-group col-2">
                                            <label for="">Date Of Passport Detail Entry</label>
                                            <input class="form-control" type="date" name="created_at" value="<?php echo e(old('created_at')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('created_at') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('created_at')): ?>
                                                <span class="error"><?php echo e($errors->first('created_at')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Date Of Orignal Passport Received</label>
                                            <input class="form-control" type="date" name="recived_passport" value="<?php echo e(old('recived_passport')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('recived_passport') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('recived_passport')): ?>
                                                <span class="error"><?php echo e($errors->first('recived_passport')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-3">
                                            <label for="">E Number</label>
                                            <input class="form-control" type="number" name="E_Number" value="<?php echo e(old('E_Number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('E_Number') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('E_Number')): ?>
                                                <span class="error"><?php echo e($errors->first('E_Number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">Other E Number</label>
                                            <input class="form-control" type="number" name="other_E_Number" value="<?php echo e(old('other_E_Number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('other_E_Number') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('other_E_Number')): ?>
                                                <span class="error"><?php echo e($errors->first('other_E_Number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">E Number Date</label>
                                            <input class="form-control" type="date" name="E_Number_date" value="<?php echo e(old('E_Number_date')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('E_Number_date') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('E_Number_date')): ?>
                                                <span class="error"><?php echo e($errors->first('E_Number_date')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">

                                        <div class="form-group col-4">
                                            <label for="">Name</label>
                                            <input class="form-control" type="text" name="name" value="<?php echo e(old('name')); ?>"class="form-control <?php echo e(isset($errors) && $errors->has('name') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('name')): ?>
                                                <span class="error"><?php echo e($errors->first('name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Father Name</label>
                                            <input class="form-control" type="text" name="father_name" value="<?php echo e(old('father_name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('father_name') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('father_name')): ?>
                                                <span class="error"><?php echo e($errors->first('father_name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">CNIC Number</label>
                                            <input class="form-control" type="text" name="cnic" value="<?php echo e(old('cnic')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('cnic') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('cnic')): ?>
                                                <span class="error"><?php echo e($errors->first('cnic')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Name(Arabic)</label>
                                            <input class="form-control" type="text" name="name_ar" value="<?php echo e(old('name_ar')); ?>"class="form-control <?php echo e(isset($errors) && $errors->has('name_ar') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('name_ar')): ?>
                                                <span class="error"><?php echo e($errors->first('name_ar')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Father Name(Arabic)</label>
                                            <input class="form-control" type="text" name="father_name_ar" value="<?php echo e(old('father_name_ar')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('father_name_ar') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('father_name_ar')): ?>
                                                <span class="error"><?php echo e($errors->first('father_name_ar')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">Phone Number</label>
                                            <input class="form-control" type="text" name="emp_phone" class="form-control <?php echo e(isset($errors) && $errors->has('emp_phone') ? 'has_error' : ''); ?>" id="" placeholder="Phone Numberr">
                                            <?php if($errors->has('emp_phone')): ?>
                                                <span class="error"><?php echo e($errors->first('emp_phone')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <h6 class="add_file_section"> Passport Details</h6>
                                    <hr>
                                    <div class="row">

                                        <div class="form-group col-4">
                                            <label for="">Passport Number</label>
                                            <input class="form-control" type="number" name="passport" value="<?php echo e(old('passport')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('passport') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('passport')): ?>
                                                <span class="error"><?php echo e($errors->first('passport')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Old Passport Number</label>
                                            <input class="form-control" type="number" name="passport_old" value="<?php echo e(old('passport_old')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('passport_old') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('passport_old')): ?>
                                                <span class="error"><?php echo e($errors->first('passport_old')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Date Of Birth</label>
                                            <input class="form-control" type="date" name="dob" value="<?php echo e(old('dob')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('dob') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('dob')): ?>
                                                <span class="error"><?php echo e($errors->first('dob')); ?><span>
                                            <?php endif; ?>
                                        </div>


                                    </div>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label for="">Place Of Birth</label>
                                            <input class="form-control" type="text" name="pob" value="<?php echo e(old('pob')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('pob') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('pob')): ?>
                                                <span class="error"><?php echo e($errors->first('pob')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Passport Date Of Issue</label>
                                            <input class="form-control" type="date" name="doi" value="<?php echo e(old('doi')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('doi') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('doi')): ?>
                                                <span class="error"><?php echo e($errors->first('doi')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Passport Date Of Expiry</label>
                                            <input class="form-control" type="date" name="doe" value="<?php echo e(old('doe')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('doe') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('doe')): ?>
                                                <span class="error"><?php echo e($errors->first('doe')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">

                                        <div class="form-group col-4">
                                            <label for="">Passport Place Of Issue</label>
                                            <input class="form-control" type="text" name="poi" value="<?php echo e(old('poi')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('poi') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('poi')): ?>
                                                <span class="error"><?php echo e($errors->first('poi')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label for="">Gender</label>
                                            <select name="sex" id='sex' class="form-control select2 <?php echo e(isset($errors) && $errors->has('sex') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Male" selected="selected">Male</option>
                                                <option value="Female" >Female</option>
                                            </select>
                                            <?php if($errors->has('sex')): ?>
                                                <span class="error"><?php echo e($errors->first('sex')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label for="">Married/Single</label>
                                            <select name="married_status" id='married_status' class="form-control select2 <?php echo e(isset($errors) && $errors->has('married_status') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Single" >Single</option>
                                                <option value="Married" selected="selected">Married</option>
                                            </select>
                                            <?php if($errors->has('married_status')): ?>
                                                <span class="error"><?php echo e($errors->first('married_status')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Province</label>
                                            <input class="form-control" type="text" name="province" value="<?php echo e(old('province')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('province') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('province')): ?>
                                                <span class="error"><?php echo e($errors->first('province')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label>City</label>
                                            <select name="employer_city_id" class="form-control select2 <?php echo e(isset($errors) && $errors->has('employer_city_id') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="1" selected="selected">Karachi</option>
                                                <option value="2" >Islamabad</option>
                                            </select>
                                            <?php if($errors->has('employer_city_id')): ?>
                                                <span class="error"><?php echo e($errors->first('employer_city_id')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-2">
                                            <label for="">District</label>
                                            <input class="form-control" type="text" name="district" value="<?php echo e(old('district')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('district') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('district')): ?>
                                                <span class="error"><?php echo e($errors->first('district')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="">Address</label>
                                            <input class="form-control" type="text" name="address" value="<?php echo e(old('address')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('address') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('address')): ?>
                                                <span class="error"><?php echo e($errors->first('address')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                    </div>
                                    <h6 class="add_file_section">Employment Details</h6>
                                    <hr>
                                    <div class="row">
                                        <?php if(isset($id)): ?>
                                            <?php
                                                $employer = DB::table('employer_details')->where('file_id',$id)->get();
                                                $sender_details = DB::table('sender_details')->where('file_id',$id)->get();
                                            ?>
                                        <?php endif; ?>

                                        <div class="form-group col-4">
                                            <label for="">Employer Name</label>
                                            <input class="form-control" type="text" name="employername" value="<?php echo e($employer[0]->name); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('employername') ? 'has_error' : ''); ?>" id="" placeholder="" disabled>
                                            <?php if($errors->has('employername')): ?>
                                                <span class="error"><?php echo e($errors->first('employername')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Visa Number</label>
                                            <input class="form-control" type="text" name="visa_number" value="<?php echo e($employer[0]->visa_number); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('visa_number') ? 'has_error' : ''); ?>" id="" placeholder="" disabled>
                                            <?php if($errors->has('visa_number')): ?>
                                                <span class="error"><?php echo e($errors->first('visa_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">ID Number</label>
                                            <input class="form-control" type="text" name="id_number" value="<?php echo e($employer[0]->id_number); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('id_number') ? 'has_error' : ''); ?>" id="" placeholder="" disabled>
                                            <?php if($errors->has('id_number')): ?>
                                                <span class="error"><?php echo e($errors->first('id_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label>Occupation</label>
                                                <?php
                                                    $categories = DB::table('categories')->select('*')->get();
                                                ?>
                                                <select name="category" class="form-control select2" style="width: 100%;">
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->name); ?>/<?php echo e($item->ar_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                        </div>
                                        

                                        <div class="form-group col-4">
                                            <label for="">Salary</label>
                                            <input class="form-control" type="number" name="salary" value="<?php echo e(old('salary')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('salary') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('salary')): ?>
                                                <span class="error"><?php echo e($errors->first('salary')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                         <div class="form-group col-4" style="display: none">
                                            <label>Salary Unit</label>
                                            <select name="salary_unit" class="form-control select2 <?php echo e(isset($errors) && $errors->has('salary_unit') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Monthly" selected="selected">Monthly</option>
                                                <option value="Daily">Daily Wages</option>
                                            </select>
                                            <?php if($errors->has('salary_unit')): ?>
                                                <span class="error"><?php echo e($errors->first('salary_unit')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-2">
                                            <label for="">Permission Number</label>
                                            <input class="form-control" type="text" name="permission_number" value="<?php echo e($sender_details[0]->permission_number); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('permission_number') ? 'has_error' : ''); ?>" id="" placeholder="" disabled>
                                            <?php if($errors->has('permission_number')): ?>
                                                <span class="error"><?php echo e($errors->first('permission_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Permission Date</label>
                                            <input class="form-control" type="text" name="permission_date" value="<?php echo e($sender_details[0]->permission_date); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('permission_date') ? 'has_error' : ''); ?>" id="" placeholder="" disabled>
                                            <?php if($errors->has('permission_date')): ?>
                                                <span class="error"><?php echo e($errors->first('permission_date')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label>VISA STATUS</label>
                                            <select name="visa_status" id='visa_status' class="form-control select2 <?php echo e(isset($errors) && $errors->has('visa_status') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Pending" selected="selected">Pending</option>
                                                <option value="Visa Submitted to Embassy" >Visa Submitted to Embassy</option>
                                                <option value="Visa Stamped" >Visa Stamped</option>
                                                <option value="Visa Rejected" >Visa Rejected</option>
                                                <option value="Visa Objection" >Visa Objection</option>
                                            </select>
                                            <?php if($errors->has('visa_status')): ?>
                                                <span class="error"><?php echo e($errors->first('visa_status')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4" id="showcontent" sty>
                                            <label for="">Objection Note</label>
                                            <input class="form-control" type="text" name="objection_note" value="<?php echo e(old('objection_note')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('objection_note') ? 'has_error' : ''); ?>" id="" placeholder="" >
                                            <?php if($errors->has('objection_note')): ?>
                                                <span class="error"><?php echo e($errors->first('objection_note')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <script>
                                        $('#visa_status').change(function() {
                                        if ($(this).val() == 4) {
                                            $('#showcontent').show();
                                        } else {
                                            $('#showcontent').hide();
                                        }
                                        });
                                    </script>
                                    <h6 class="add_file_section">Insurance Details</h6>
                                    <hr>
                                    <div class="row">
                                      <div class="form-group col-4">
                                            <label for="">Name</label>
                                            <input class="form-control" type="text" name="employer_name" value="<?php echo e(old('employer_name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('employer_name') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('employer_name')): ?>
                                                <span class="error"><?php echo e($errors->first('employer_name')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                         <div class="form-group col-4">
                                            <label for="">Father Name/ Husband Name</label>
                                            <input class="form-control" type="text" name="nomination_name" value="<?php echo e(old('nomination_name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('nomination_name') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('nomination_name')): ?>
                                                <span class="error"><?php echo e($errors->first('nomination_name')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                          <div class="form-group col-4">
                                            <label for="">Nomination Cnic</label>
                                            <input class="form-control" type="number" name="nomination_cnic" value="<?php echo e(old('nomination_cnic')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('nomination_cnic') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('nomination_cnic')): ?>
                                                <span class="error"><?php echo e($errors->first('nomination_cnic')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label for="">Relation</label>
                                            <input class="form-control" type="text" name="relation" value="<?php echo e(old('relation')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('relation') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('relation')): ?>
                                                <span class="error"><?php echo e($errors->first('relation')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Gender</label>
                                            <select name="sex_nomination" id='sex_nomination' class="form-control select2 <?php echo e(isset($errors) && $errors->has('sex_nomination') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Male" selected="selected">Male</option>
                                                <option value="Female" >Female</option>
                                            </select>
                                            <?php if($errors->has('sex_nomination')): ?>
                                                <span class="error"><?php echo e($errors->first('sex_nomination')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label for="">Nomination Address</label>
                                            <input class="form-control" type="text" name="nomination_address" value="<?php echo e(old('nomination_address')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('nomination_address') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('nomination_address')): ?>
                                                <span class="error"><?php echo e($errors->first('nomination_address')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <h6 class="add_file_section">Ticket Details</h6>
                                    <hr>
                                    <div class="row">
                                        <div class="form-group col-3">
                                            <label for="">Airline Name</label>
                                            <input class="form-control" type="text" name="Airline_Name" value="<?php echo e(old('Airline_Name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Airline_Name') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Airline_Name')): ?>
                                                <span class="error"><?php echo e($errors->first('Airline_Name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">Ticket Number</label>
                                            <input class="form-control" type="text" name="Ticket_no" value="<?php echo e(old('Ticket_no')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Ticket_no') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Ticket_no')): ?>
                                                <span class="error"><?php echo e($errors->first('Ticket_no')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">Ticket From</label>
                                            <input class="form-control" type="text" name="Ticket_From" value="<?php echo e(old('Ticket_From')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Ticket_From') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Ticket_From')): ?>
                                                <span class="error"><?php echo e($errors->first('Ticket_From')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-3">
                                            <label for="">Ticket To</label>
                                            <input class="form-control" type="text" name="Ticket_To" value="<?php echo e(old('Ticket_To')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Ticket_To') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Ticket_To')): ?>
                                                <span class="error"><?php echo e($errors->first('Ticket_To')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Date Of Departure</label>
                                            <input class="form-control" type="date" name="Date_Of_Departure" value="<?php echo e(old('Date_Of_Departure')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Date_Of_Departure') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Date_Of_Departure')): ?>
                                                <span class="error"><?php echo e($errors->first('Date_Of_Departure')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Departure Time</label>
                                            <input class="form-control" type="text" name="Departure_Time" value="<?php echo e(old('Departure_Time')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Ticket_From') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Departure_Time')): ?>
                                                <span class="error"><?php echo e($errors->first('Departure_Time')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label for="">Arrival Time</label>
                                            <input class="form-control" type="text" name="Arrival_Time" value="<?php echo e(old('Arrival_Time')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Arrival_Time') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Arrival_Time')): ?>
                                                <span class="error"><?php echo e($errors->first('Arrival_Time')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <h6 class="add_file_section">Passport Delivery</h6>
                                    <hr>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label for="">Passport Delivery Type</label>
                                            <select name="Passport_Delivery_Type" id='Passport_Delivery_Type' class="form-control select2 <?php echo e(isset($errors) && $errors->has('Passport_Delivery_Type') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Couriers" selected="selected">Couriers</option>
                                                <option value="Couriers" >By Hand</option>
                                            </select>
                                            <?php if($errors->has('Passport_Delivery_Type')): ?>
                                                <span class="error"><?php echo e($errors->first('Passport_Delivery_Type')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-3">
                                            <label for="">Passport Delivered To Name</label>
                                            <input class="form-control" type="text" name="Passport_Delivery_To_Name" value="<?php echo e(old('Passport_Delivery_To_Name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Passport_Delivery_To_Name') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Passport_Delivery_To_Name')): ?>
                                                <span class="error"><?php echo e($errors->first('Passport_Delivery_To_Name')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label for="">Date Of Delivery</label>
                                            <input class="form-control" type="date" name="Date_Of_Delivery" value="<?php echo e(old('Date_Of_Delivery')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('Date_Of_Delivery') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('Date_Of_Delivery')): ?>
                                                <span class="error"><?php echo e($errors->first('Date_Of_Delivery')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>

    </div>
    <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visa_portal_BI\resources\views/frontend/file/add_employee.blade.php ENDPATH**/ ?>