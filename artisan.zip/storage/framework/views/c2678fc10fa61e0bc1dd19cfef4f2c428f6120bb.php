    
    <?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Add File</h1>
                    </div>
                    <div class="col-sm-6">
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!--New File Entry Form Start-->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <!-- form start -->
                            <form role="form">
                                <?php echo e(csrf_field()); ?>

                                <div class="card-body">
                                    <h6> New File Entry
                                        <span style="float:right; margin-right:1000px;">
                                            <?php if(session()->has('success')): ?>
                                                <?php echo e(session()->get('success')); ?>

                                                
                                            <?php elseif(session()->has('error')): ?>
                                                <?php echo e(session()->get('error')); ?>

                                                
                                            <?php endif; ?>
                                        </span>
                                    </h6>

                                    <hr>
                                    <div class="row">
                                        <div class="form-group col-3">
                                            <label>Country</label>
                                            <select name="country" class="form-control select2 <?php echo e(isset($errors) && $errors->has('country') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="1" <?php echo e(old('country') && old('country') == "1" ? 'selected' : 'selected'); ?>>Pakistan</option>
                                            </select>
                                            <?php if($errors->has('country')): ?>
                                                <span class="error"><?php echo e($errors->first('country')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label>City</label>
                                            <select name="city" class="form-control select2 <?php echo e(isset($errors) && $errors->has('city') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="1" <?php echo e(old('city') && old('city') == "1" ? 'selected' : ''); ?>>Karachi</option>
                                                <option value="2" <?php echo e(old('city') && old('city') == "2" ? 'selected' : ''); ?>>Islamabad</option>
                                            </select>
                                            <?php if($errors->has('city')): ?>
                                                <span class="error"><?php echo e($errors->first('city')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-6">
                                            <label>Date</label>
                                            <input type="text" name="date" value="<?php echo e(old('date')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('date') ? 'has_error' : ''); ?>" id="date_time" readonly>
                                            <?php if($errors->has('date')): ?>
                                                <span class="error"><?php echo e($errors->first('date')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <h6 class="add_file_section"> Forign Employer Details</h6>
                                    <hr>

                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="">Name Of Employer (English)</label>
                                            <input type="text" name="name" value="<?php echo e(old('name')); ?>"class="form-control <?php echo e(isset($errors) && $errors->has('name') ? 'has_error' : ''); ?>" id="" placeholder="Enter Name Employer (English)">
                                            <?php if($errors->has('name')): ?>
                                                <span class="error"><?php echo e($errors->first('name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-6">
                                            <label for="">Name Of Employer (Arabic)</label>
                                            <input type="text" name="ar_name" value="<?php echo e(old('ar_name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('ar_name') ? 'has_error' : ''); ?>" id="" placeholder="Enter Name Employer (Arabic)">
                                            <?php if($errors->has('ar_name')): ?>
                                                <span class="error"><?php echo e($errors->first('ar_name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-3">
                                            <label>Type of Employer</label>
                                            <select name="type" class="form-control select2 <?php echo e(isset($errors) && $errors->has('type') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Private" selected="selected">Private</option>
                                                <option value="Company">Company</option>
                                            </select>
                                            <?php if($errors->has('type')): ?>
                                                <span class="error"><?php echo e($errors->first('type')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">Visa Number</label>
                                            <input type="text" name="visa_number" value="<?php echo e(old('visa_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('visa_number') ? 'has_error' : ''); ?>" id="" placeholder="Enter Visa Number">
                                            <?php if($errors->has('visa_number')): ?>
                                                <span class="error"><?php echo e($errors->first('visa_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">ID Number /Company CR No</label>
                                            <input type="number" name="id_number" value="<?php echo e(old('id_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('id_number') ? 'has_error' : ''); ?>" id="" placeholder="Enter ID Number">
                                            <?php if($errors->has('id_number')): ?>
                                                <span class="error"><?php echo e($errors->first('id_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label>City</label>
                                            <select name="employer_city" class="form-control select2 <?php echo e(isset($errors) && $errors->has('employer_city') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="1" <?php echo e(old('employer_city') && old('employer_city') == "1" ? 'selected' : ''); ?>>Karachi</option>
                                                <option value="2" <?php echo e(old('employer_city') && old('employer_city') == "2" ? 'selected' : ''); ?>>Islamabad</option>
                                            </select>
                                            <?php if($errors->has('employer_city')): ?>
                                                <span class="error"><?php echo e($errors->first('employer_city')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        
                                    </div>

                                    <div class="row">

                                        <div class="form-group col-6">
                                            <label for="">Visa Issue Date (Arabic)</label>
                                            <input type="text" name="issue_date" value="<?php echo e(old('issue_date')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('issue_date') ? 'has_error' : ''); ?>" id="" placeholder="Enter Issue Date">
                                            <?php if($errors->has('issue_date')): ?>
                                                <span class="error"><?php echo e($errors->first('issue_date')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-6">
                                            <label for="">Address</label>
                                            <input type="text" name="address" value="<?php echo e(old('address')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('address') ? 'has_error' : ''); ?>" id="" placeholder="Enter Address">
                                            <?php if($errors->has('address')): ?>
                                                <span class="error"><?php echo e($errors->first('address')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-3">
                                            <label for="">Fax Number</label>
                                            <input type="number" name="fax_number" value="<?php echo e(old('fax_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('fax_number') ? 'has_error' : ''); ?>" id="" placeholder="Enter Fax Number">
                                            <?php if($errors->has('fax_number')): ?>
                                                <span class="error"><?php echo e($errors->first('fax_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">Mobile Number</label>
                                            <input type="number" name="mobile_number" value="<?php echo e(old('mobile_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('mobile_number') ? 'has_error' : ''); ?>" id="" placeholder="Enter Mobile Number">
                                            <?php if($errors->has('mobile_number')): ?>
                                                <span class="error"><?php echo e($errors->first('mobile_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">Phone Number</label>
                                            <input type="number" name="phone_number" value="<?php echo e(old('phone_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('phone_number') ? 'has_error' : ''); ?>" id="" placeholder="Enter Phone Number">
                                            <?php if($errors->has('phone_number')): ?>
                                                <span class="error"><?php echo e($errors->first('phone_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="">Email Address</label>
                                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('email') ? 'has_error' : ''); ?>" id="" placeholder="Enter Email Address">
                                            <?php if($errors->has('email')): ?>
                                                <span class="error"><?php echo e($errors->first('email')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="">Website</label>
                                            <input type="text" name="website" value="<?php echo e(old('website')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('website') ? 'has_error' : ''); ?>" id="" placeholder="Enter Website">
                                            <?php if($errors->has('website')): ?>
                                                <span class="error"><?php echo e($errors->first('website')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        
                                    </div>

                                    <h6 class="add_file_section"> Foreign Employment Details</h6>
                                    <hr>
                                    <div class="foreign_employment_details_section">
                                        <div  class="foreign_employment_details">
                                            <div class="row">
                                                <div class="form-group col-1">
                                                    <label for="">Total Visas</label>
                                                    <input type="number" name="total_visa[]" class="form-control" id="" placeholder="">
                                                </div>
                                                <div class="form-group col-3">
                                                    <label>Occupation</label>
                                                    <?php
                                                    $categories = DB::table('categories')->select('*')->get();


                                                    ?>
                                                    <select name="category[]" class="form-control select2" style="width: 100%;">
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" ><?php echo e($item->name); ?>/<?php echo e($item->ar_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-2">
                                                    <label for="">Salary</label>
                                                    <div class="input-group-append">
                                                        <input type="number" name="salary[]" class="form-control" id="" placeholder="">
                                                        <select name="salary_unit[]" class="form-control select2">
                                                            <option value="Monthly" selected="selected">Monthly</option>
                                                            <option value="Daily Wages">Daily Wages</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group col-3">
                                                    <label for="">Period Of Contract (Years)</label>
                                                    <input type="text" name="contract_year[]" class="form-control" id="" placeholder="No of Years">
                                                </div>
                                                <div class="form-group col-3">
                                                    <label for="">Period Of Contract (Months)</label>
                                                    <input type="text" name="contract_month[]" class="form-control" id="" placeholder="No of Months">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="form-group col-1">
                                                    <label>Commision</label>
                                                    <select name="commision[]" class="form-control select2" style="width: 100%;">
                                                        <option value="Yes">Yes</option>
                                                        <option value="No"selected="selected">No</option>
                                                    </select>
                                                </div>
                                                <!-- <div class="form-group col-4 hide" id="commision_detail_section">
                                                    <label>Details</label>
                                                    <input type="text" name="commision_detail[]" value="<?php echo e(old('commision_detail')); ?>" class="form-control">
                                                    <?php if($errors->has('commision_detail')): ?>
                                                        <span class="error"><?php echo e($errors->first('commision_detail')); ?><span>
                                                    <?php endif; ?>
                                                </div> -->
                                                <div class="form-group col-1">
                                                    <label>Overtime</label>
                                                    <select name="overtime[]" value="<?php echo e(old('overtime')); ?>" class="form-control select2" style="width: 100%;">
                                                        <option value="Yes">Yes</option>
                                                        <option value="No" selected="selected">No</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-2">
                                                    <label>Free Accommodation</label>
                                                    <select name="free_accommodation[]" class="form-control select2 details"
                                                        style="width: 100%;">
                                                        <option value="Yes">Yes</option>
                                                        <option value="No" selected="selected">No</option>
                                                    </select>
                                                </div>
                                                <!-- <div class="form-group col-4 hide" id="free_accommodation_detail_section">
                                                    <label>Details</label>
                                                    <input type="text" name="free_accommodation_detail[]" value="<?php echo e(old('free_accommodation_detail')); ?>" class="form-control">
                                                    <?php if($errors->has('free_accommodation_detail')): ?>
                                                        <span class="error"><?php echo e($errors->first('free_accommodation_detail')); ?><span>
                                                    <?php endif; ?>
                                                </div> -->
                                                <div class="form-group col-1">
                                                    <label>Free Food</label>
                                                    <select name="free_food[]" class="form-control select2 details"
                                                        style="width: 100%;">
                                                        <option value="Yes">Yes</option>
                                                        <option value="No" selected="selected">No</option>
                                                    </select>
                                                </div>
                                                <!-- <div class="form-group col-4 hide" id="free_food_detail_section">
                                                    <label>Details</label>
                                                    <input type="text" name="free_food_detail[]" value="<?php echo e(old('free_food_detail')); ?>" class="form-control">
                                                    <?php if($errors->has('free_food_detail')): ?>
                                                        <span class="error"><?php echo e($errors->first('free_food_detail')); ?><span>
                                                    <?php endif; ?>
                                                </div> -->
                                                <div class="form-group col-1">
                                                    <label>Work Place City</label>
                                                    <select name="working_place[]" class="form-control select2 details"
                                                        style="width: 100%;">
                                                        <option value="Makkah">Makkah</option>
                                                        <option value="Jeddah" selected="selected">Jeddah</option>
                                                    </select>
                                                </div>
                                                <!-- <div class="form-group col-4 hide" id="working_place_detail_section">
                                                    <label for="">Details</label>
                                                    <input type="text" name="working_place_detail[]" value="<?php echo e(old('working_place_detail')); ?>" class="form-control">
                                                    <?php if($errors->has('working_place_detail')): ?>
                                                        <span class="error"><?php echo e($errors->first('working_place_detail')); ?><span>
                                                    <?php endif; ?>
                                                </div> -->
                                                <div class="form-group col-2">
                                                    <label>Duty Time(In Hours)</label>
                                                    <input type="text" name="duty_time[]" class="form-control" id="" placeholder="No of Hours">
                                                </div>
                                                <div class="form-group col-1 hide" id="duty_time_detail_section">
                                                    <label for="">Details</label>
                                                    <input type="text" name="duty_time_detail[]" class="form-control" id="" placeholder="No of Months">
                                                </div>
                                                <div class="form-group col-1">
                                                    <label>Other Benefits</label>
                                                    <select name="other_benefits[]" class="form-control select2 details" style="width: 100%;">
                                                        <option value="Yes">Yes</option>
                                                        <option value="No" selected="selected">No</option>
                                                    </select>
                                                </div>
                                                <!-- <div class="form-group col-4 hide" id="other_benefits_section">
                                                    <label for="">Details</label>
                                                    <input type="text" name="other_benefits_detail[]" value="<?php echo e(old('other_benefits_detail')); ?>" class="form-control" id="" placeholder="No of Months">
                                                    <?php if($errors->has('other_benefits_detail')): ?>
                                                        <span class="error"><?php echo e($errors->first('other_benefits_detail')); ?><span>
                                                    <?php endif; ?>
                                                </div> -->
                                                <div class="form-group col-1">
                                                    <label>Free Tickets</label>
                                                    <select name="free_tickets[]" class="form-control select2" style="width: 100%;">
                                                        <option value="Yes">Yes</option>
                                                        <option value="No" selected="selected">No</option>
                                                    </select>
                                                </div>
                                                <!-- <div class="form-group col-4 hide">
                                                    <label for="">Details</label>
                                                    <input type="text" name="free_tickets_detail[]" value="<?php echo e(old('free_tickets_detail')); ?>" class="form-control" id="free_tickets_detail_section" placeholder="No of Months">
                                                    <?php if($errors->has('free_tickets_detail')): ?>
                                                        <span class="error"><?php echo e($errors->first('free_tickets_detail')); ?><span>
                                                    <?php endif; ?>
                                                </div> -->
                                                <div class="form-group col-1">
                                                    <label>Medical Insurance</label>
                                                    <select name="medical_insurance[]" class="form-control select2" style="width: 100%;">
                                                        <option value="Yes">Yes</option>
                                                        <option value="No" selected="selected">No</option>
                                                    </select>
                                                </div>
                                                <!-- <div class="form-group col-4 hide">
                                                    <label for="">Details</label>
                                                    <input type="text" name="medical_insurance_detail[]" value="<?php echo e(old('medical_insurance_detail')); ?>" class="form-control" id="medical_insurance_detail_section" placeholder="No of Months">
                                                    <?php if($errors->has('medical_insurance_detail')): ?>
                                                        <span class="error"><?php echo e($errors->first('medical_insurance_detail')); ?><span>
                                                    <?php endif; ?>
                                                </div> -->
                                                <div class="form-group col-1">
                                                    <label>Transpotation</label>
                                                    <select name="transportaion[]" class="form-control select2" style="width: 100%;">
                                                        <option value="Yes">Yes</option>
                                                        <option value="No" selected="selected">No</option>
                                                    </select>
                                                </div>
                                                <!-- <div class="form-group col-4 hide">
                                                    <label for="">Details</label>
                                                    <input type="text" name="transportaion_detail[]" value="<?php echo e(old('transportaion_detail')); ?>" class="form-control" id="transportaion_detail_section" placeholder="No of Months">
                                                    <?php if($errors->has('transportaion_detail')): ?>
                                                        <span class="error"><?php echo e($errors->first('transportaion_detail')); ?><span>
                                                    <?php endif; ?>
                                                </div> -->
                                            </div>
                                        </div>
                                    </div>
                                    <input type="button" value="Add more" class="add_more_employment">
                                    <!-- <buttton type="submit" class="add_more_employment">Add more</button> -->

                                    <h6 class="add_file_section">Sender Details</h6>
                                    <hr>

                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="">Visa Sender Name</label>
                                            <input type="text" name="sender_name" value="<?php echo e(old('sender_name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('sender_name') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('sender_name')): ?>
                                                <span class="error"><?php echo e($errors->first('sender_name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Nationality</label>
                                            <input type="text" name="sender_nationality" value="<?php echo e(old('sender_nationality')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('sender_nationality') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('sender_nationality')): ?>
                                                <span class="error"><?php echo e($errors->first('sender_nationality')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Mobile Number</label>
                                            <input type="number" name="sender_mobile_number" value="<?php echo e(old('sender_mobile_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('sender_mobile_number') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('sender_mobile_number')): ?>
                                                <span class="error"><?php echo e($errors->first('sender_mobile_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label>City</label>
                                            <select name="sender_city" class="form-control select2 <?php echo e(isset($errors) && $errors->has('sender_city') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="1" <?php echo e(old('sender_city') && old('sender_city') == "1" ? 'selected' : ''); ?>>Karachi</option>
                                                <option value="2" <?php echo e(old('sender_city') && old('sender_city') == "2" ? 'selected' : ''); ?>>Islamabad</option>
                                            </select>
                                            <?php if($errors->has('sender_city')): ?>
                                                <span class="error"><?php echo e($errors->first('sender_city')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-8">
                                            <label>Processing / Recruitment</label>
                                            <select name="processing_recruitment" class="form-control select2 <?php echo e(isset($errors) && $errors->has('processing_recruitment') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Processing" <?php echo e(old('processing_recruitment') && old('processing_recruitment') == "1" ? 'selected' : ''); ?>>Processing</option>
                                                <option value="Processing Direct" <?php echo e(old('processing_recruitment') && old('processing_recruitment') == "1" ? 'selected' : ''); ?>>Processing Direct</option>
                                                <option value="Recruitment" <?php echo e(old('processing_recruitment') && old('processing_recruitment') == "2" ? 'selected' : ''); ?>>Recruitment</option>
                                            </select>
                                            <?php if($errors->has('processing_recruitment')): ?>
                                                <span class="error"><?php echo e($errors->first('processing_recruitment')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Amount</label>
                                            <input type="number" name="amount" value="<?php echo e(old('amount')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('amount') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('amount')): ?>
                                                <span class="error"><?php echo e($errors->first('amount')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Other Expenses</label>
                                            <input type="number" name="other_expense" value="<?php echo e(old('other_expense')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('other_expense') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('other_expense')): ?>
                                                <span class="error"><?php echo e($errors->first('other_expense')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-8">
                                            <label for="">Other Details</label>
                                            <input type="text" name="other_details" value="<?php echo e(old('other_details')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('other_details') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('other_details')): ?>
                                                <span class="error"><?php echo e($errors->first('other_details')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Permission Number</label>
                                            <input type="text" name="permission_number" value="<?php echo e(old('permission_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('permission_number') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('permission_number')): ?>
                                                <span class="error"><?php echo e($errors->first('permission_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Permission Date</label>
                                            <input type="date" name="permission_date" value="<?php echo e(old('permission_date')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('permission_date') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('permission_date')): ?>
                                                <span class="error"><?php echo e($errors->first('permission_date')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" name="" class="btn btn-primary btn_add_file">Submit</button>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>

    </div>
    <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visa_portal_BI\resources\views/frontend/file/add_file.blade.php ENDPATH**/ ?>