    
    <?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Add Category</h1>
                    </div>
                    <div class="col-sm-6">
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!--New File Entry Form Start-->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <!-- form start -->
                            <form role="form" action="<?php echo e(url('add-Category')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <div class="card-body">
                                    <h6> New Category Entry
                                        <span style="float:right; margin-right:1000px;">
                                            <?php if(session()->has('success')): ?>
                                                <?php echo e(session()->get('success')); ?>

                                                
                                            <?php elseif(session()->has('error')): ?>
                                                <?php echo e(session()->get('error')); ?>

                                                
                                            <?php endif; ?>
                                        </span>
                                    </h6>


                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="">Name Of Category (English)</label>
                                            <input type="text" name="name" value="<?php echo e(old('name')); ?>"class="form-control <?php echo e(isset($errors) && $errors->has('name') ? 'has_error' : ''); ?>" id="" placeholder="Enter Name Employer (English)">
                                            <?php if($errors->has('name')): ?>
                                                <span class="error"><?php echo e($errors->first('name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-6">
                                            <label for="">Name Of Category (Arabic)</label>
                                            <input type="text" name="ar_name" value="<?php echo e(old('ar_name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('ar_name') ? 'has_error' : ''); ?>" id="" placeholder="Enter Name Employer (Arabic)">
                                            <?php if($errors->has('ar_name')): ?>
                                                <span class="error"><?php echo e($errors->first('ar_name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" name="" class="btn btn-primary btn_add_file">Submit</button>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>

    </div>
    <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visa_portal_BI\resources\views/frontend/file/add_Category.blade.php ENDPATH**/ ?>