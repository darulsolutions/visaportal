    <?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Employee / Visa Details</h1>
                    </div>
                    <div class="col-sm-6">

                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!--New File Entry Form Start-->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <!-- form start -->
                            <form role="form" method="post" action="<?php echo e(url('add-employee')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <h4 class="add_file_section">Employee Visa Details</h4>
                                        </div>
                                        <div class="form-group col-6">
                                            <div class="card-footer">
                                                <a href="" type="submit" class="btn btn-primary">Print Forms</a>
                                            </div>
                                        </div>

                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Name:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->name) && !empty($employee_details[0]->name) ? $employee_details[0]->name : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('name')): ?>
                                                <span class="error"><?php echo e($errors->first('name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Father Name:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->father_name) && !empty($employee_details[0]->father_name) ? $employee_details[0]->father_name : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('father_name')): ?>
                                                <span class="error"><?php echo e($errors->first('father_name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>CNIC Number:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->cnic) && !empty($employee_details[0]->cnic) ? $employee_details[0]->cnic : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="cnic" value="<?php echo e(old('cnic')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('cnic') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('cnic')): ?>
                                                <span class="error"><?php echo e($errors->first('cnic')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label style='font-weight:bold;'>Address:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->address) && !empty($employee_details[0]->address) ? $employee_details[0]->address : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="address" value="<?php echo e(old('address')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('address') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('address')): ?>
                                                <span class="error"><?php echo e($errors->first('address')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Category:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->category) && !empty($employee_details[0]->category) ? $employee_details[0]->category : ''); ?>" id="" placeholder="">
                                            <!-- <select name="category" class="form-control select2" style="width: 100%;">
                                                <option value="1" >Category A</option>
                                                <option value="2">Category B</option>
                                            </select> -->
                                        </div>
                                         <div class="form-group col-2">
                                            <label style='font-weight:bold;'>District:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->district) && !empty($employee_details[0]->district) ? $employee_details[0]->district : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="district" value="<?php echo e(old('district')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('district') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('district')): ?>
                                                <span class="error"><?php echo e($errors->first('district')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Date Of Birth:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->dob) && !empty($employee_details[0]->dob) ? $employee_details[0]->dob : ''); ?>" id="" placeholder="">
                                            <!-- <input type="date" name="dob" value="<?php echo e(old('dob')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('dob') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('dob')): ?>
                                                <span class="error"><?php echo e($errors->first('dob')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Place Of Birth:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->pob) && !empty($employee_details[0]->pob) ? $employee_details[0]->pob : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="pob" value="<?php echo e(old('pob')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('pob') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('pob')): ?>
                                                <span class="error"><?php echo e($errors->first('pob')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Passport Number:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->passport) && !empty($employee_details[0]->passport) ? $employee_details[0]->passport : ''); ?>" id="" placeholder="">
                                            <!-- <input type="number" name="passport" value="<?php echo e(old('passport')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('passport') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('passport')): ?>
                                                <span class="error"><?php echo e($errors->first('passport')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Date Of Issue:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->doi) && !empty($employee_details[0]->doi) ? $employee_details[0]->doi : ''); ?>" id="" placeholder="">
                                            <!-- <input type="date" name="doi" value="<?php echo e(old('doi')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('doi') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('doi')): ?>
                                                <span class="error"><?php echo e($errors->first('doi')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Place Of Issue:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->poi) && !empty($employee_details[0]->poi) ? $employee_details[0]->poi : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="poi" value="<?php echo e(old('poi')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('poi') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('poi')): ?>
                                                <span class="error"><?php echo e($errors->first('poi')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Date Of E:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->doe) && !empty($employee_details[0]->doe) ? $employee_details[0]->doe : ''); ?>" id="" placeholder="">
                                            <!-- <input type="date" name="doe" value="<?php echo e(old('doe')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('doe') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('doe')): ?>
                                                <span class="error"><?php echo e($errors->first('doe')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Province:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->province) && !empty($employee_details[0]->province) ? $employee_details[0]->province : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="province" value="<?php echo e(old('province')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('province') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('province')): ?>
                                                <span class="error"><?php echo e($errors->first('province')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label style='font-weight:25px;'>City:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->father_name) && !empty($employee_details[0]->father_name) ? $employee_details[0]->father_name : ''); ?>" id="" placeholder="">
                                            <!-- <select name="employer_city_id" class="form-control select2 <?php echo e(isset($errors) && $errors->has('employer_city_id') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="1" selected="selected">Karachi</option>
                                                <option value="2" >Islamabad</option>
                                            </select> -->
                                            <?php if($errors->has('employer_city_id')): ?>
                                                <span class="error"><?php echo e($errors->first('employer_city_id')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Contract Period:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->contract_period) && !empty($employee_details[0]->contract_period) ? $employee_details[0]->contract_period : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="contract_period" value="<?php echo e(old('contract_period')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('contract_period') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('contract_period')): ?>
                                                <span class="error"><?php echo e($errors->first('contract_period')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Salary:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->salary) && !empty($employee_details[0]->salary) ? $employee_details[0]->salary : ''); ?>" id="" placeholder="">
                                            <!-- <input type="number" name="salary" value="<?php echo e(old('salary')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('salary') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('salary')): ?>
                                                <span class="error"><?php echo e($errors->first('salary')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                         <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Salary Unit:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->salary_unit) && !empty($employee_details[0]->salary_unit) ? $employee_details[0]->salary_unit : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('salary_unit')): ?>
                                                <span class="error"><?php echo e($errors->first('salary_unit')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Permission Number:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->permission_number) && !empty($employee_details[0]->permission_number) ? $employee_details[0]->permission_number : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('permission_number')): ?>
                                                <span class="error"><?php echo e($errors->first('permission_number')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Date:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->date) && !empty($employee_details[0]->date) ? $employee_details[0]->date : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('date')): ?>
                                                <span class="error"><?php echo e($errors->first('date')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <h4 class="add_file_section">Insurance Details                                    </h4>

                                    <hr>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Name:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->employer_name) && !empty($employee_details[0]->employer_name) ? $employee_details[0]->employer_name : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('employer_name')): ?>
                                                <span class="error"><?php echo e($errors->first('employer_name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Nomination Father Name/ Husband Name:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->nomination_name) && !empty($employee_details[0]->nomination_name) ? $employee_details[0]->nomination_name : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('nomination_name')): ?>
                                                <span class="error"><?php echo e($errors->first('nomination_name')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                          <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Nomination Cnic:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->nomination_cnic) && !empty($employee_details[0]->nomination_cnic) ? $employee_details[0]->nomination_cnic : ''); ?>" id="" placeholder="">
                                            <!-- <input type="number" name="nomination_cnic" value="<?php echo e(old('nomination_cnic')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('nomination_cnic') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('nomination_cnic')): ?>
                                                <span class="error"><?php echo e($errors->first('nomination_cnic')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Relation:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->relation) && !empty($employee_details[0]->relation) ? $employee_details[0]->relation : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="relation" value="<?php echo e(old('relation')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('relation') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('relation')): ?>
                                                <span class="error"><?php echo e($errors->first('relation')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Nomination Address:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->nomination_address) && !empty($employee_details[0]->nomination_address) ? $employee_details[0]->nomination_address : ''); ?>" id="" placeholder="">
                                            <!-- <input type="number" name="kd_number" value="<?php echo e(old('nomination_address')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('nomination_address') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('nomination_address')): ?>
                                                <span class="error"><?php echo e($errors->first('nomination_address')); ?><span>
                                            <?php endif; ?>
                                        </div>

                                      <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Employee Date:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->emp_date) && !empty($employee_details[0]->emp_date) ? $employee_details[0]->emp_date : ''); ?>" id="" placeholder="">
                                            <!-- <input type="date" name="emp_date" value="<?php echo e(old('emp_date')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('emp_date') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('emp_date')): ?>
                                                <span class="error"><?php echo e($errors->first('emp_date')); ?><span>
                                            <?php endif; ?>
                                      </div>
                                    </div>
                                    <div class="row">
                                        
                                         
                                         <div class="form-group col-4">
                                            <label style='font-weight:bold;'>Gender:</label>
                                            <input type="text"  class="form-control"  value="<?php echo e(isset($employee_details[0]->sex) && !empty($employee_details[0]->sex) ? $employee_details[0]->sex : ''); ?>" id="" placeholder="">
                                            <!-- <input type="text" name="sex" value="<?php echo e(old('sex')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('sex') ? 'has_error' : ''); ?>" id="" placeholder=""> -->
                                            <?php if($errors->has('sex')): ?>
                                                <span class="error"><?php echo e($errors->first('sex')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->

                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>

    </div>
    <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visa_portal_BI\resources\views/frontend/file/employee_details.blade.php ENDPATH**/ ?>