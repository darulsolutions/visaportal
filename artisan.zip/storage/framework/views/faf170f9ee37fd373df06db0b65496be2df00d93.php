    
    <?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Add Sender</h1>
                    </div>
                    <div class="col-sm-6">
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!--New File Entry Form Start-->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <!-- form start -->
                            <form role="form">
                                <?php echo e(csrf_field()); ?>

                                <div class="card-body">
                                    <h6> Sender Details
                                        <span style="float:right; margin-right:1000px;">
                                            <?php if(session()->has('success')): ?>
                                                <?php echo e(session()->get('success')); ?>

                                                
                                            <?php elseif(session()->has('error')): ?>
                                                <?php echo e(session()->get('error')); ?>

                                                
                                            <?php endif; ?>
                                        </span>
                                    </h6>

                                    <hr>

                                    <h6 class="add_file_section">Sender Details</h6>
                                    <hr>
                                    <form action="<?php echo e(url('')); ?>" method="POST">
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="">Visa Sender Name</label>
                                            <input type="text" name="sender_name" value="<?php echo e(old('sender_name')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('sender_name') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('sender_name')): ?>
                                                <span class="error"><?php echo e($errors->first('sender_name')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Nationality</label>
                                            <input type="text" name="sender_nationality" value="<?php echo e(old('sender_nationality')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('sender_nationality') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('sender_nationality')): ?>
                                                <span class="error"><?php echo e($errors->first('sender_nationality')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Mobile Number</label>
                                            <input type="number" name="sender_mobile_number" value="<?php echo e(old('sender_mobile_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('sender_mobile_number') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('sender_mobile_number')): ?>
                                                <span class="error"><?php echo e($errors->first('sender_mobile_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label>City</label>
                                            <select name="sender_city" class="form-control select2 <?php echo e(isset($errors) && $errors->has('sender_city') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="1" <?php echo e(old('sender_city') && old('sender_city') == "1" ? 'selected' : ''); ?>>Karachi</option>
                                                <option value="2" <?php echo e(old('sender_city') && old('sender_city') == "2" ? 'selected' : ''); ?>>Islamabad</option>
                                            </select>
                                            <?php if($errors->has('sender_city')): ?>
                                                <span class="error"><?php echo e($errors->first('sender_city')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-8">
                                            <label>Processing / Recruitment</label>
                                            <select name="processing_recruitment" class="form-control select2 <?php echo e(isset($errors) && $errors->has('processing_recruitment') ? 'has_error' : ''); ?>" style="width: 100%;">
                                                <option value="Processing" <?php echo e(old('processing_recruitment') && old('processing_recruitment') == "1" ? 'selected' : ''); ?>>Processing</option>
                                                <option value="Processing Direct" <?php echo e(old('processing_recruitment') && old('processing_recruitment') == "1" ? 'selected' : ''); ?>>Processing Direct</option>
                                                <option value="Recruitment" <?php echo e(old('processing_recruitment') && old('processing_recruitment') == "2" ? 'selected' : ''); ?>>Recruitment</option>
                                            </select>
                                            <?php if($errors->has('processing_recruitment')): ?>
                                                <span class="error"><?php echo e($errors->first('processing_recruitment')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Amount</label>
                                            <input type="number" name="amount" value="<?php echo e(old('amount')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('amount') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('amount')): ?>
                                                <span class="error"><?php echo e($errors->first('amount')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Other Expenses</label>
                                            <input type="number" name="other_expense" value="<?php echo e(old('other_expense')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('other_expense') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('other_expense')): ?>
                                                <span class="error"><?php echo e($errors->first('other_expense')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-8">
                                            <label for="">Other Details</label>
                                            <input type="text" name="other_details" value="<?php echo e(old('other_details')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('other_details') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('other_details')): ?>
                                                <span class="error"><?php echo e($errors->first('other_details')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Permission Number</label>
                                            <input type="text" name="permission_number" value="<?php echo e(old('permission_number')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('permission_number') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('permission_number')): ?>
                                                <span class="error"><?php echo e($errors->first('permission_number')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-2">
                                            <label for="">Permission Date</label>
                                            <input type="date" name="permission_date" value="<?php echo e(old('permission_date')); ?>" class="form-control <?php echo e(isset($errors) && $errors->has('permission_date') ? 'has_error' : ''); ?>" id="" placeholder="">
                                            <?php if($errors->has('permission_date')): ?>
                                                <span class="error"><?php echo e($errors->first('permission_date')); ?><span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" name="" class="btn btn-primary btn_add_file">Submit</button>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>

    </div>
    <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visa_portal_BI\resources\views/frontend/file/add_sender.blade.php ENDPATH**/ ?>