<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>NEW REQUEST LETTER PERMISSION</title>
    <style>
        @media(max-width: 450px){
            form{
                width: 100% !important;
                font-size: 15px;
            }
            .permission{
                display: block;
            }
        }
    </style>
  </head>
  <body>
      <div class="mainSection"style="padding: 30px;font-size:20px">
        <form action="" style="width:70%;margin: 0 auto;">
        <p>
              To, <span class="dateToday"style="float: right;">Date: 01-12-2020</span>  <br>
              The Protector of Emigrants; <br>
              Government of Pakistan; <br>
              Karachi; 

          </p>
          <p>Subject: <span class="permission" style="text-decoration: underline;font-weight: 600;
            padding-left: 10%;">GRANT OF PERMISSION</span></p>
            <p style="padding-top:10px">
                Your Excellency,
            </p>
            <p>
                We request you to kindly grant the Permission No. <span style="font-weight: 600;">569302 </span>  Dated: <span style="font-weight: 600;"> 27-10-2020</span> M/s <span style="font-weight: 600;"> HANI BIN MUHAMMAD BIN RADADAL SAFYANI.</span> for enables us to interview and registration.


            </p>
            <p style="padding-top:10px">
                Furthermore, this is to inform you that we shall working for the protector process against this permission.
            </p>
            <p style="padding-top:20px">
                We have attached required documents with this letter and requested to kindly grant the permission. 
            </p>
            <p style="padding-top: 100px;">
                BASHIR IBRAHIM ENTERPRISES <br>
                PROPRIETOR                                                         

            </p>
        </form>  
      </div>
    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\visa_portal_BI\resources\views/Bashir_Forms/NEW_REQUEST_LETTER_PERMISSION.blade.php ENDPATH**/ ?>